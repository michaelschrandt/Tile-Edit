------------------
-   Tile Edit    -
-                -
-       by       -
-                -
-Michael Schrandt-
------------------
-    1/3/2013    -
------------------

-------------
-Description-
-------------
-Tile Edit is a tile-based map editor which includes basic drawing functionality, layered editing, and collision support.

----------------
-Creating a Map-
----------------
-After launching the editor, you will need to load in a tilesheet. Before doing this, make sure the 'Tile Width' box is consistent with your tilesheet. 

-Once the tiles are loaded in, you may select a tile and begin drawing on the grid. You may also fill in a region by selecting the "Fill" option on the toolbar.

-The bottom panel contains layer information. You may select a different layer, which will be the new drawing surface. You may disable check boxes to hide layers below the activated layer.

-The collision layer is used to mark solid objects.

----------------
-Saving/Loading-
----------------
-To save a map, simply click the yellow "Save Map" arrow and provide a name for the output file.

-To load a map, ensure that you have the associated tilesheet loaded in first, as well as the proper tile width. Then click the green "Load Map" arrow and select your map file.

--------------------------
-Understanding the Output-
--------------------------
-Once you have created a map, you may export it to a text file. This text file contains all of the data necessary to recreate your map, aside from the tilesheet.

-The text file is layed out as follows:

y z						<- y is the map width, z is the map height

x x x x ... x           <- This is layer 1. Each x represents the INDEX where the tile is located within the tilesheet.
x x x x ... x           <- Indexes begin at 1, where 0 means no tile was placed.
  .                     <- An index of 1 is the first tile in the tilesheet, 2 is the tile to the right of that, and this pattern will continue eventually onto the next row.
  .                     
  .                    
x x x x ... x           

x x x x ... x           <- Layer 2
x x x x ... x           
  .
  .
  .
x x x x ... x

x x x x ... x           <- Layer 3
x x x x ... x
  .
  .
  .
x x x x ... x

x x x x ... x           <- Collision layer
x x x x ... x			<- 1 represents "marked," 0 represents "unmarked"
  .
  .
  .
x x x x ... x

---------
-Credits-
---------
- This application was made in C# using Windows Presentation Forms
- WPF Extended Toolkit version 1.8 (Ms-LP)
- Sample Tilesheet: http://telles0808.deviantart.com/art/RPG-Maker-VX-RTP-Tileset-159218223